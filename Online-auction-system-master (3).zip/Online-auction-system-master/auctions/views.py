
from decimal import Decimal, InvalidOperation

from django import forms
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import (
    User,
    Item,
    Bid,
    ItemComment,
    Watchlist,
    ItemCategory,
    AuctionHistory,
)


# --------------------------------------------------
# FORMS
# --------------------------------------------------

class ItemForm(forms.ModelForm):

    CATEGORY_CHOICES = [
        ("clothing", "Clothing"),
        ("toys", "Toys"),
        ("electronics", "Electronics"),
        ("art", "Art"),
    ]

    category = forms.ChoiceField(
        choices=CATEGORY_CHOICES,
        widget=forms.Select(attrs={"class": "form-control"})
    )

    class Meta:
        model = Item
        fields = [
            "title",
            "description",
            "img_url",
            "starting_bid",
            "category",
        ]

        widgets = {
            "title": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Item title"
                }
            ),
            "description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "placeholder": "Item description",
                    "rows": 4,
                }
            ),
            "img_url": forms.URLInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Image URL",
                }
            ),
            "starting_bid": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Starting bid",
                    "step": "0.01",
                    "min": "0.01",
                }
            ),
        }

    def clean_starting_bid(self):
        amount = self.cleaned_data["starting_bid"]

        if amount <= 0:
            raise forms.ValidationError(
                "Starting bid must be greater than zero."
            )

        return amount


class CommentForm(forms.Form):

    commentText = forms.CharField(
        max_length=512,
        widget=forms.Textarea(
            attrs={
                "class": "form-control",
                "placeholder": "Write your comment...",
                "rows": 3,
            }
        )
    )


# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------

def get_item_from_request(request):

    listing_id = (
        request.POST.get("listing_id")
        or request.GET.get("listing_id")
    )

    if listing_id:
        return get_object_or_404(Item, id=listing_id)

    listing_title = (
        request.POST.get("listing_title")
        or request.GET.get("listing_title")
    )

    if listing_title:
        item = Item.objects.filter(
            title=listing_title
        ).order_by("id").first()

        if item:
            return item

    return None


def get_items_with_bids(items):

    items_with_bids = []

    for item in items:

        highest_bid = (
            Bid.objects.filter(items=item)
            .order_by("-amount", "-id")
            .first()
        )

        current_bid = (
            highest_bid if highest_bid
            else item.starting_bid
        )

        items_with_bids.append((item, current_bid))

    return items_with_bids


def redirect_to_listing(item):

    return redirect(
        f"/listing_details?listing_id={item.id}"
    )


# --------------------------------------------------
# HOME PAGE
# --------------------------------------------------

def index(request):

    if request.method == "POST":

        if not request.user.is_authenticated:
            messages.error(
                request,
                "Please log in to use the watchlist."
            )
            return redirect("auctions:login")

        item = get_item_from_request(request)

        if item is None:
            messages.error(request, "Listing not found.")
            return redirect("auctions:index")

        if item.user_id == request.user.id:

            messages.error(
                request,
                "You cannot add your own listing to your watchlist."
            )

        else:

            _, created = Watchlist.objects.get_or_create(
                user=request.user,
                items=item
            )

            if created:
                messages.success(
                    request,
                    "Item added to your watchlist."
                )
            else:
                messages.info(
                    request,
                    "This item is already in your watchlist."
                )

        return redirect("auctions:index")

    items = Item.objects.filter(
        status=True
    ).order_by("-id")

    items_bids = get_items_with_bids(items)

    distinct_users = User.objects.filter(
        item_list__isnull=False
    ).distinct()

    context = {
        "items": items,
        "items_bids": items_bids,
        "distinct_users": distinct_users,
        "json": "[]",
        "json_users": "[]",
        "CommentForm": CommentForm(),
    }

    return render(
        request,
        "auctions/index.html",
        context
    )


# --------------------------------------------------
# LOGIN
# --------------------------------------------------

def login_view(request):

    if request.user.is_authenticated:
        return redirect("auctions:index")

    if request.method == "POST":

        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            login(request, user)

            messages.success(
                request,
                "Login successful."
            )

            return redirect("auctions:index")

        messages.error(
            request,
            "Invalid username or password."
        )

    return render(
        request,
        "auctions/login.html"
    )


# --------------------------------------------------
# LOGOUT
# --------------------------------------------------

@login_required
def logout_view(request):

    logout(request)

    return redirect("auctions:index")


# --------------------------------------------------
# REGISTER
# --------------------------------------------------

def register(request):

    if request.user.is_authenticated:
        return redirect("auctions:index")

    if request.method == "POST":

        username = request.POST.get(
            "username", ""
        ).strip()

        email = request.POST.get(
            "email", ""
        ).strip()

        password = request.POST.get(
            "password", ""
        )

        confirmation = request.POST.get(
            "confirmation", ""
        )

        if not username or not email or not password:

            messages.error(
                request,
                "Please fill in all required fields."
            )

            return render(
                request,
                "auctions/register.html"
            )

        if password != confirmation:

            messages.error(
                request,
                "Passwords must match."
            )

            return render(
                request,
                "auctions/register.html"
            )

        try:

            user = User.objects.create_user(
                username=username,
                email=email,
                password=password
            )

            login(request, user)

            messages.success(
                request,
                "Registration successful."
            )

            return redirect("auctions:index")

        except IntegrityError:

            messages.error(
                request,
                "This username is already taken."
            )

    return render(
        request,
        "auctions/register.html"
    )


# --------------------------------------------------
# ADD NEW LISTING
# --------------------------------------------------

@login_required
def add(request):

    if request.method == "POST":

        form = ItemForm(request.POST)

        if form.is_valid():

            item = form.save(commit=False)

            item.user = request.user
            item.status = True

            item.save()

            ItemCategory.objects.get_or_create(
                name=item.category,
                item=item
            )

            messages.success(
                request,
                "Your listing was created successfully."
            )

            return redirect("auctions:index")

    else:

        form = ItemForm()

    return render(
        request,
        "auctions/add.html",
        {"new_form": form}
    )


# --------------------------------------------------
# CARDS PAGE
# --------------------------------------------------

@login_required
def cards_view(request):

    items = Item.objects.filter(
        user=request.user
    ).order_by("-id")

    return render(
        request,
        "auctions/cards.html",
        {
            "items": items,
            "user": request.user,
        }
    )


# --------------------------------------------------
# LISTING DETAILS
# --------------------------------------------------

def listing_details_view(request):

    item = get_item_from_request(request)

    if item is None:

        messages.error(
            request,
            "Please select a valid listing."
        )

        return redirect("auctions:index")

    highest_bid = (
        Bid.objects.filter(items=item)
        .order_by("-amount", "-id")
        .first()
    )

    comments = ItemComment.objects.filter(
        item=item
    ).select_related(
        "author"
    ).order_by("-id")

    is_owner = (
        request.user.is_authenticated
        and item.user_id == request.user.id
    )

    context = {
        "item": item,
        "last_bid": (
            highest_bid.amount
            if highest_bid
            else item.starting_bid
        ),
        "highest_bid": highest_bid,
        "comments": comments,
        "is_owner": is_owner,
        "message_bid": "",
        "CommentForm": CommentForm(),
    }

    return render(
        request,
        "auctions/listing_details.html",
        context
    )


# --------------------------------------------------
# ADD COMMENT
# --------------------------------------------------

@login_required
@require_POST
def add_comment(request):

    item = get_item_from_request(request)

    if item is None:

        messages.error(
            request,
            "Listing not found."
        )

        return redirect("auctions:index")

    comment_text = request.POST.get(
        "commentText", ""
    ).strip()

    if not comment_text:

        messages.error(
            request,
            "Comment cannot be empty."
        )

        return redirect_to_listing(item)

    if len(comment_text) > 512:

        messages.error(
            request,
            "Comment is too long."
        )

        return redirect_to_listing(item)

    ItemComment.objects.create(
        text=comment_text,
        item=item,
        author=request.user
    )

    messages.success(
        request,
        "Comment added successfully."
    )

    return redirect_to_listing(item)


# --------------------------------------------------
# WATCHLIST
# --------------------------------------------------

@login_required
def watchlist_view(request):

    watchlist_items = Watchlist.objects.filter(
        user=request.user
    ).select_related(
        "items",
        "items__user"
    ).order_by("-id")

    return render(
        request,
        "auctions/watchlist.html",
        {
            "watchlist": watchlist_items
        }
    )


# --------------------------------------------------
# ADD TO WATCHLIST
# --------------------------------------------------

@login_required
@require_POST
def add_to_watchlist(request):

    item = get_item_from_request(request)

    if item is None:

        messages.error(
            request,
            "Listing not found."
        )

        return redirect("auctions:index")

    if item.user_id == request.user.id:

        messages.error(
            request,
            "You cannot add your own listing to your watchlist."
        )

        return redirect_to_listing(item)

    _, created = Watchlist.objects.get_or_create(
        user=request.user,
        items=item
    )

    if created:

        messages.success(
            request,
            "Item added to your watchlist."
        )

    else:

        messages.info(
            request,
            "Item is already in your watchlist."
        )

    return redirect("auctions:watchlist")


# --------------------------------------------------
# REMOVE FROM WATCHLIST
# --------------------------------------------------

@login_required
@require_POST
def delete_item_watchlist(request):

    item = get_item_from_request(request)

    if item is None:

        messages.error(
            request,
            "Listing not found."
        )

        return redirect("auctions:watchlist")

    Watchlist.objects.filter(
        user=request.user,
        items=item
    ).delete()

    messages.success(
        request,
        "Item removed from your watchlist."
    )

    return redirect("auctions:watchlist")


# --------------------------------------------------
# CATEGORY LIST
# --------------------------------------------------

def category_list(request):

    categories = [
        "clothing",
        "toys",
        "electronics",
        "art",
    ]

    return render(
        request,
        "auctions/categories.html",
        {"categories": categories}
    )


# --------------------------------------------------
# CATEGORY LISTING
# --------------------------------------------------

def category_list_redirect(request, category):

    items = Item.objects.filter(
        category__iexact=category,
        status=True
    ).order_by("-id")

    items_bids = get_items_with_bids(items)

    return render(
        request,
        "auctions/category_listing.html",
        {
            "category": category,
            "items": items,
            "items_bids": items_bids,
        }
    )


# --------------------------------------------------
# PLACE BID
# --------------------------------------------------

@login_required
@require_POST
def place_bid(request):

    item = get_item_from_request(request)

    if item is None:

        messages.error(
            request,
            "Listing not found."
        )

        return redirect("auctions:index")

    if not item.status:

        messages.error(
            request,
            "This auction has already ended."
        )

        return redirect_to_listing(item)

    if item.user_id == request.user.id:

        messages.error(
            request,
            "You cannot place a bid on your own listing."
        )

        return redirect_to_listing(item)

    try:

        new_bid = Decimal(
            request.POST.get("new_bid", "").strip()
        )

        if not new_bid.is_finite() or new_bid <= 0:
            raise InvalidOperation

    except (InvalidOperation, ValueError, TypeError):

        messages.error(
            request,
            "Please enter a valid bid amount."
        )

        return redirect_to_listing(item)

    highest_bid = (
        Bid.objects.filter(items=item)
        .order_by("-amount", "-id")
        .first()
    )

    current_highest = (
        highest_bid.amount
        if highest_bid
        else item.starting_bid
    )

    if new_bid <= current_highest:

        messages.error(
            request,
            f"Your bid must be greater than ₹{current_highest}."
        )

        return redirect_to_listing(item)

    Bid.objects.create(
        user=request.user,
        amount=new_bid,
        items=item
    )

    messages.success(
        request,
        "Your bid was placed successfully."
    )

    return redirect_to_listing(item)


# --------------------------------------------------
# END AUCTION
# --------------------------------------------------

@login_required
@require_POST
def end_listing(request):

    item = get_item_from_request(request)

    if item is None:

        messages.error(
            request,
            "Listing not found."
        )

        return redirect("auctions:index")

    if item.user_id != request.user.id:

        messages.error(
            request,
            "Only the seller can end this auction."
        )

        return redirect_to_listing(item)

    if not item.status:

        messages.info(
            request,
            "This auction has already ended."
        )

        return redirect_to_listing(item)

    with transaction.atomic():

        locked_item = Item.objects.select_for_update().get(
            id=item.id
        )

        if not locked_item.status:

            messages.info(
                request,
                "This auction has already ended."
            )

            return redirect_to_listing(locked_item)

        highest_bid = (
            Bid.objects.filter(items=locked_item)
            .select_related("user")
            .order_by("-amount", "-id")
            .first()
        )

        if highest_bid:

            AuctionHistory.objects.get_or_create(
                user=highest_bid.user,
                items=locked_item
            )

        locked_item.status = False

        locked_item.save(
            update_fields=["status"]
        )

    if highest_bid:

        messages.success(
            request,
            f"Auction ended. Winner: {highest_bid.user.username}"
        )

    else:

        messages.info(
            request,
            "Auction ended without any bids."
        )

    return redirect_to_listing(item)


# --------------------------------------------------
# AUCTION HISTORY
# --------------------------------------------------

@login_required
def auctions_history(request):

    history_records = AuctionHistory.objects.filter(
        user=request.user
    ).select_related(
        "items"
    ).order_by("-id")

    items_bids = []

    for history in history_records:

        winning_bid = (
            Bid.objects.filter(
                items=history.items,
                user=request.user
            )
            .order_by("-amount", "-id")
            .first()
        )

        if winning_bid:

            items_bids.append(
                (history.items, winning_bid)
            )

    return render(
        request,
        "auctions/auctions_won.html",
        {"items_bids": items_bids}
    )
